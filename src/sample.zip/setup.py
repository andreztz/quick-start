import os
from setuptools import setup
from setuptools import find_packages


def readme():
    with open("README.md") as f:
        return f.read()


def required():
    with open("requirements.txt") as f:
        return f.read().splitlines()


package = {
    "name": "my_package_name",
    "version": "my_package_name",
    "description": "my_description",
    "long_description": readme(),
    "long_description_content_type": "text/markdown",
    "keywords": "my_package_keywords",
    "author": "my_author",
    "author_email": "my_author_email",
    "url": "my_url",
    "license": "my_license",
    "packages": find_packages(),
    "install_requires": required(),
    "entry_points": {"console_scripts": ["my_command_name=src.__main__:main"]},
    "classifiers": [
        "Development Status :: 1 - Planning",
        "Environment :: Console",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
    ],
}

setup(**package)
