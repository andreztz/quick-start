root_dir = os.path.abspath(os.path.dirname(__file__))


def main():
    print(root_dir)
